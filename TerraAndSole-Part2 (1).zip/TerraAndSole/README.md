# Terra & Sole — Website Project

## Project Title
Terra & Sole — E-commerce Website (WEDE5020 Portfolio of Evidence)

## Student Information
- **Name:** Tashnick Jasmith
- **Student Number:** ST10519821
- **Module:** WEDE5020
- **Group:** N/A

## Project Overview
Terra & Sole is a Cape Town-based handcrafted leather footwear brand founded in 2021,
built on vegetable-tanned leather and ethical sourcing. The brand currently has no
digital presence and relies entirely on in-person markets and two stockist boutiques.

This project delivers a website that establishes Terra & Sole's first online storefront,
allowing the brand to sell directly to consumers, build brand awareness among
sustainability-minded shoppers, and educate visitors on its handcrafting process and
ethical sourcing.

## Website Goals and Objectives
- Establish a credible online storefront to sell directly to consumers, reducing
  reliance on third-party retailers.
- Increase brand awareness among sustainability-minded shoppers.
- Educate visitors on the brand's ethical sourcing and handcrafting process.

**Key Performance Indicators (KPIs)**
- 20% of total sales occurring online within 6 months of launch.
- Average session duration of 2+ minutes on the homepage and product pages.
- Email newsletter sign-up rate of at least 5% of unique visitors.

## Key Features and Functionality
- Homepage with hero banner, featured products, and brand story teaser.
- Products page with shoe listings (filtering by type/size/colour planned for a later phase).
- About Us page detailing the brand's history, mission, and sustainability practices.
- Enquiry page with a form for product enquiries.
- Contact page with contact details, multiple locations (workshop + stockist boutiques), and a contact form.
- Secure checkout with card and EFT (planned for a later development phase).

## Design Direction
- **Colour palette:** terracotta `#C97C4B`, cream `#F5F1E8`, charcoal `#2E2A22`.
- **Typography:** Aptos for body copy; a serif display font for headings.
- **Layout:** minimalist, image-led, mobile-first, single-column with generous white space.

## Timeline and Milestones
| Weeks | Milestone |
|---|---|
| 1–2 | Discovery, content gathering, and wireframing |
| 3–5 | Visual design and prototyping |
| 6–9 | Front-end and back-end development |
| 10 | Content population and testing (UAT) |
| 11 | Launch and post-launch monitoring |

## Part 1 Details
Part 1 covers project setup and the initial HTML skeleton:
- Content research and sourcing plan established.
- Website sitemap and file/folder structure created (see `sitemap.svg`).
- Five core HTML pages created with semantic structure and working navigation:
  `index.html`, `about.html`, `products.html`, `enquiry.html`, `contact.html`.
- Repository initialised and pushed to GitHub.

## Part 2 Details
Part 2 covers CSS styling and responsive design, building on the Part 1 HTML skeleton:
- Fixed two invalid CSS declarations carried over from Part 1 (`var (--color-charcoal)`
  had a stray space, and `background-color:white (--color-cream)` mixed a keyword and a
  variable into one invalid value).
- Rebuilt `css/style.css` with a minimal CSS reset, a brand variable system (colour,
  fluid typography scale via `clamp()`, spacing scale), and consistent use of the
  cascade so most elements are styled through a small number of selectors (`section`,
  `form input/textarea/select`, `.product-card`) rather than one-off IDs.
- Applied typography styling (`font-family`, fluid `font-size`, `line-height`,
  letter-spacing on nav links) using a serif display font (Playfair Display, loaded
  from Google Fonts) for headings and the brand's Aptos/system-sans stack for body copy.
- Built layout structure with CSS Grid and Flexbox: a two-column hero on desktop
  (single-column on mobile), a responsive product grid (1 / 2 / 3 columns depending on
  breakpoint), and a flex-based header/nav.
- Added visual styling (background colours, borders, rounded corners, box-shadow on
  cards) and interactive pseudo-classes (`:hover`, `:focus-visible`, `:active`) on nav
  links, buttons, form fields, and product cards.
- Implemented mobile-first responsive design with two breakpoints (`min-width: 48em`
  tablet, `min-width: 64em` desktop), relative units (`rem`, `em`, `%`, `clamp()`) for
  spacing and type instead of fixed pixels, and `width: 100%` / `max-width: 100%` on
  images so they scale within their containers.
- Added a `.hero-text` wrapper `<div>` around the homepage hero copy so it could be
  targeted as a single grid item alongside the hero image.
- Screenshot evidence of the desktop, tablet, and mobile layouts should be added to
  this section before submission (browser dev tools → device toolbar, or an actual
  phone/tablet).

*Part 3 (JavaScript interactivity / back-end) will follow in a future submission.*

## Sitemap
See `sitemap.svg` in this repository for the visual site structure. In summary:

- [Home](index.html)
  - [About Us](about.html)
  - [Products](products.html)
  - [Enquiry](enquiry.html)
  - [Contact](contact.html)

All five pages are reachable from a persistent navigation menu on every page.

## Folder Structure
```
TerraAndSole/
```
- [index.html](index.html)
- [about.html](about.html)
- [products.html](products.html)
- [enquiry.html](enquiry.html)
- [contact.html](contact.html)
- [sitemap.svg](sitemap.svg)
- [README.md](README.md)
- css/
  - [style.css](css/style.css)
- js/
  - [script.js](js/script.js)
- images/

## Changelog
| Date | Change |
|---|---|
| 2026-08-07 | Initial project setup: folder structure, sitemap, and five core HTML pages created. |
| 2026-09-16 | Part 2 feedback/corrections: fixed two invalid CSS declarations from Part 1 (`var (--color-charcoal)` and the malformed `background-color` value). |
| 2026-09-16 | Part 2 — CSS styling: added a CSS reset, brand colour/typography/spacing variables, fluid type scale, and a serif display heading font (Playfair Display). |
| 2026-09-16 | Part 2 — layout: implemented CSS Grid for the hero section and product grid, and Flexbox for header/nav; added a `.hero-text` wrapper div in `index.html` to support the hero grid layout. |
| 2026-09-16 | Part 2 — visual/interactive styling: added box-shadow cards, rounded corners, and `:hover`/`:focus-visible`/`:active` states across nav links, buttons, form fields, and product cards. |
| 2026-09-16 | Part 2 — responsive design: added mobile-first breakpoints at 48em (tablet) and 64em (desktop) using media queries, switched spacing/typography to relative units (`rem`, `em`, `%`, `clamp()`), and made images fluid (`max-width: 100%`). |

## References
Afrihost. 2026. Web Hosting Packages. Available at: https://www.afrihost.com [Accessed 2 August 2026].

WooCommerce. 2026. WooCommerce Pricing and Features. Available at: https://woocommerce.com [Accessed 2 August 2026].

W3Schools. 2026. HTML and CSS Tutorials. Available at: https://www.w3schools.com [Accessed 2 August 2026].
