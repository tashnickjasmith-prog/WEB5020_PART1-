// Terra & Sole — script.js
// Placeholder for interactive functionality (product filtering, cart, form
// validation, etc.). To be built out in Part 3 of the project.

console.log("Terra & Sole site loaded.");
